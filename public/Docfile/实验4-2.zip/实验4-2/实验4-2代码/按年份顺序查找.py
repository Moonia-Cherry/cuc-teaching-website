import pandas as pd
import time

def sequential_search(file_path):
    try:
        # 读取数据（注意处理可能的空值）
        df = pd.read_excel(file_path, engine='openpyxl')
        df['年份'] = pd.to_numeric(df['年份'], errors='coerce')  # 确保年份为数值类型
        
        # 记录开始时间
        start_time = time.perf_counter()
        
        # 顺序查找核心算法
        results = []
        for index, row in df.iterrows():
            if 2015 <= row['年份'] <= 2018:
                results.append(row.to_dict())
        
        # 计算耗时
        elapsed = (time.perf_counter() - start_time) * 1000  # 毫秒
        
        return results, elapsed
    
    except Exception as e:
        print(f"程序异常：{str(e)}")
        return [], 0

# 使用示例
movies, time_cost = sequential_search('movie_data.xlsx')
print(f"找到{len(movies)}部符合条件的电影，耗时{time_cost:.2f}毫秒")
print("前5条结果：")
print(pd.DataFrame(movies[:5]).to_string(index=False))