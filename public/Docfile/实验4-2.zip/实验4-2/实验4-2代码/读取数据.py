import pandas as pd
from pathlib import Path

def read_movie_data(file_path):
    """
    读取电影数据文件
    参数说明：
    file_path - 文件路径（建议使用绝对路径）
    返回值：
    DataFrame格式的电影数据
    """
    try:
        # 读取Excel文件
        df = pd.read_excel(file_path, engine='openpyxl')
        
        # 验证数据格式
        required_columns = ['名称', '年份', '导演', '演员', '类型', '国别', '语言', '评分', '简介']
        if not all(col in df.columns for col in required_columns):
            raise ValueError("数据文件格式不符合要求")
            
        return df
    
    except FileNotFoundError:
        print("文件未找到，请检查路径是否正确")
    except Exception as e:
        print(f"数据读取错误: {str(e)}")
def create_director_archive(movie_df):
    """
    创建导演艺术档案库
    参数：
    movie_df - 电影数据DataFrame
    返回值：
    导演档案字典（包含完整作品信息）
    """
    director_archive = {}
    
    # 遍历每部电影（体现线性数据结构思想）
    for index, row in movie_df.iterrows():
        director = row['导演']
        movie_info = {
            "片名": row['名称'],
            "年份": row['年份'],
            "类型": row['类型'].split(','),  # 支持多类型标签
            "评分": row['评分'],
            "主演": row['演员'].split(','),  # 支持多人主演
            "国别": row['国别']
        }
        
        # 建立导演与作品的映射关系（字典核心应用）
        if director not in director_archive:
            director_archive[director] = {
                "国籍": row['国别'],  # 假设导演国籍与电影国别一致
                "作品集": []
            }
        director_archive[director]["作品集"].append(movie_info)
    
    return director_archive
# 示例使用（注意修改为实际路径）
file_path = Path("movie_data.xlsx").absolute()
movie_data = read_movie_data(file_path)

# 创建导演档案柜
director_db = create_director_archive(movie_data)
print(director_db)
# 打印张艺谋导演档案（示例）
print("饺子导演作品：")
for work in director_db.get("饺子", {}).get("作品集", []):
    print(f"{work['片名']} ({work['年份']}) 评分：{work['评分']}")

# # 展示前5部电影信息
# print("前5部电影信息：")
# print(movie_data)