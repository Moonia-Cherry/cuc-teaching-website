import pandas as pd
import time

def build_director_archive():
    """构建导演档案柜"""
    try:
        # 读取数据（仅加载必要列）
        df = pd.read_excel('movie_data.xlsx', 
                          engine='openpyxl',
                          usecols=["名称", "导演", "年份", "评分"])
        
        # 数据清洗（处理空值/空格/分割导演）
        df['导演'] = df['导演'].str.strip().fillna('未知')
        
        # 创建导演档案字典
        director_dict = {}
        for _, row in df.iterrows():
            movie_info = {
                "名称": row['名称'],
                "年份": row['年份'],
                "评分": row['评分']
            }
            # 处理联合导演情况（如"姜文, 张艺谋"）
            directors = [d.strip() for d in row['导演'].split(',')]
            for director in directors:
                if director not in director_dict:
                    director_dict[director] = []
                director_dict[director].append(movie_info)
        
        return director_dict

    except Exception as e:
        print(f"数据加载失败：{str(e)}")
        return {}

def query_director(director_dict, name):
    """查询特定导演作品"""
    start = time.perf_counter()
    result = director_dict.get(name, [])
    elapsed = (time.perf_counter() - start) * 1e6  # 微秒
    return result, elapsed

# 主程序
if __name__ == "__main__":
    # 构建档案柜
    archive = build_director_archive()
    
    # 查询姜文作品
    movies, cost = query_director(archive, "姜文")
    
    # 结果输出
    print(f"【姜文导演作品查询】")
    print(f"找到{len(movies)}部作品，耗时{cost:.2f}微秒")
    print("详细信息：")
    print(pd.DataFrame(movies).to_string(index=False))