import pandas as pd
import time

def search_jiangwen_movies():
    try:
        # 读取数据（注意处理中文编码）
        df = pd.read_excel('movie_data.xlsx', 
                          engine='openpyxl',
                          usecols=["名称", "导演", "年份", "评分"])
        
        # 数据预处理（处理空值/空格）
        df['导演'] = df['导演'].str.strip().fillna('未知')

        # 精确计时（仅计算查找耗时）
        start_time = time.perf_counter()
        
        # 顺序查找核心算法
        results = []
        for index, row in df.iterrows():
            if "姜文" in row['导演']:  # 处理联合导演情况
                results.append({
                    "名称": row['名称'],
                    "年份": row['年份'],
                    "评分": row['评分']
                })
        
        elapsed = (time.perf_counter() - start_time) * 1000  # 毫秒

        # 结果输出
        print(f"找到{len(results)}部姜文导演的电影，耗时{elapsed:.2f}毫秒")
        print("详细信息：")
        print(pd.DataFrame(results).to_string(index=False))

    except FileNotFoundError:
        print("文件未找到，请确认文件路径正确")
    except KeyError:
        print("列名不匹配，请检查数据表头")

# 执行查询
search_jiangwen_movies()