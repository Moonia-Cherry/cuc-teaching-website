import pandas as pd
import time
import bisect

def binary_search(file_path):
    try:
        # 数据预处理
        df = pd.read_excel(file_path, engine='openpyxl')
        df['年份'] = pd.to_numeric(df['年份'], errors='coerce')
        
        # 按年份排序（二分查找前提条件）
        sorted_df = df.sort_values(by='年份').reset_index(drop=True)
        years = sorted_df['年份'].tolist()

        # 计时开始
        start_time = time.perf_counter()
        
        # 二分查找核心算法
        left = bisect.bisect_left(years, 2015)
        right = bisect.bisect_right(years, 2018)
        results = sorted_df.iloc[left:right].to_dict('records')

        # 计算耗时
        elapsed = (time.perf_counter() - start_time) * 1000  # 毫秒
        
        return results, elapsed

    except Exception as e:
        print(f"程序异常：{str(e)}")
        return [], 0

# 使用示例
movies, time_cost = binary_search('movie_data.xlsx')
print(f"找到{len(movies)}部符合条件的电影，耗时{time_cost:.2f}毫秒")
print("前5条结果：")
print(pd.DataFrame(movies[:5]).to_string(index=False))